﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pierre_Papier_Ciseaux
{
    internal class Program
    {
        static void Main(string[] args)
        {
            bool isPlaying = true;
               
            Console.WriteLine("Pierre, Papier, Ciseaux Game");
            Console.WriteLine("[Jouer]");
            Console.WriteLine("[Quitter]");

            while (isPlaying == true)
            {
                               
                string MainChoice = Console.ReadLine().Trim().ToLower();
               
                if (MainChoice == "jouer")
                {  
                    while (MainChoice != "quitter")
                    {
                        Console.WriteLine("Choisissez : Pierre, Papier ou Ciseaux ?");
                        string PlayerChoice = Console.ReadLine().Trim().ToLower();


                        while (PlayerChoice != "pierre" && PlayerChoice != "papier" && PlayerChoice != "ciseaux" && PlayerChoice != "quitter")
                        {
                            Console.WriteLine("Commande invalide");
                            PlayerChoice = Console.ReadLine().Trim().ToLower();
                        }

                        string[] options = { "pierre", "papier", "ciseaux" };
                        Random rand = new Random();
                        string ComputerChoice = options[rand.Next(0, options.Length)];

                        Console.WriteLine($"Joueur : {PlayerChoice}");
                        Console.WriteLine($"Computer : {ComputerChoice}");


                        if (PlayerChoice == ComputerChoice)
                        {
                            Console.WriteLine("Égalité");
                        }                  
                        else if ((PlayerChoice == "pierre" && ComputerChoice == "ciseaux") || (PlayerChoice == "ciseaux" && ComputerChoice == "papier") || (PlayerChoice == "papier" && ComputerChoice == "pierre"))
                        {
                            Console.WriteLine($"Vous avez gagné !");
                        }
                        else if (PlayerChoice == "quitter")
                        {
                            Environment.Exit(0);
                        }
                        else
                        {
                            Console.WriteLine("Vous avez perdu !");
                        }
                    }
                    
                }
                else if (MainChoice == "quitter")
                {
                    isPlaying = false;
                }
                else if (MainChoice != "jouer")
                {
                    Console.WriteLine("Entrez une commande valide");
                }
                
            }
        }
    }
}
